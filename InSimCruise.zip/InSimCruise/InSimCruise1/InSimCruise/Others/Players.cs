﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InSimDotNet;

namespace InSimCruise.Others
{
    public class Players
    {
        public static Dictionary<byte, Players> _players = new Dictionary<byte, Players>();

        public byte UCID = new byte();
        public byte PLID = new byte();

        public string PName = string.Empty;
        public string CName = string.Empty;
    }
}
