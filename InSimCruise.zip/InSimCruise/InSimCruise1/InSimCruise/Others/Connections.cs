﻿using InSimDotNet.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InSimCruise.Others
{
    class Connections
    {
        public static Dictionary<byte, Connections> _connections = new Dictionary<byte, Connections>();

        public byte UCID = new byte();
        public byte PLID = new byte();

        public string UName = string.Empty;
        public string PName = string.Empty;
        public string IP = string.Empty;
        public string Car = string.Empty;
        public string Location = "Nenhum";

        public bool Administrador = false;

        public int Distance = new int();
        public int Money = 0;
        public int BonusPorcentagem = 0;
        public int BonusMultiplicador = 0;

        public long X = 0;
        public long Y = 0;
        public long Z = 0;

        public long Heading = new long();
        public long Angle = new long();

        public long Speed = 0;

        public long KMH()
        {
            return (long)MathHelper.SpeedToKph(Speed);
        }

    }
}
