﻿using System;
using System.Timers;
using System.Windows.Forms;
using InSimDotNet;
using InSimCruise.Packages;
using InSimDotNet.Packets;
using InSimCruise.Others;

namespace InSimCruise
{
    public partial class Form1 : Form
    {
        public InSim insim;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void InitializeInSim()
        {
            insim = new InSim();

            if (!insim.IsConnected)
            {

                insim.Bind<IS_NCN>(ConnectionEnter.NCN);
                insim.Bind<IS_NPL>(ConnectionNew.NPL);
                insim.Bind<IS_PLL>(ConnectionLeft.PLL);
                insim.Bind<IS_PLP>(ConnectionLeft.PLP);
                insim.Bind<IS_BTC>(ButtonsClick.BTC);
                insim.Bind<IS_MCI>(CarInformations.MCI);
                insim.Bind<IS_UCO>(CircleInSim.UCO);
                insim.Bind<IS_MSO>(Commands.MSO);
                insim.Bind<IS_UCO>(UCO);

                insim.Initialize(new InSimSettings
                {
                    Host = textBox1.Text,
                    Port = int.Parse(textBox2.Text),
                    Admin = textBox3.Text,
                    Flags = InSimFlags.ISF_MSO_COLS | InSimFlags.ISF_MCI,
                    Interval = 1000,
                    Prefix = '!',
                    IName = "^7LFS ^1Street"
                });

                insim.Send(new IS_TINY { ReqI = 2, SubT = TinyType.TINY_NCN });
                insim.Send(new IS_TINY { ReqI = 2, SubT = TinyType.TINY_NPL });
                insim.Send(new IS_TINY { ReqI = 2, SubT = TinyType.TINY_NCI });
                insim.Send(new IS_TINY { ReqI = 2, SubT = TinyType.TINY_SST });
                insim.Send(new IS_TINY { ReqI = 2, SubT = TinyType.TINY_AXI });
                insim.Send(new IS_TINY { ReqI = 2, SubT = TinyType.TINY_ISM });

                System.Timers.Timer TimerInSim = new System.Timers.Timer(60000);
                TimerInSim.Elapsed += new System.Timers.ElapsedEventHandler(MessageInSim);
                TimerInSim.Enabled = true;

                System.Timers.Timer TimerLights = new System.Timers.Timer(1000);
                TimerLights.Elapsed += new System.Timers.ElapsedEventHandler(Semaphore);
                TimerLights.Enabled = true;
            }
        }

        public int timerSem = 0;
        public int idle = 0;

        private void UCO (InSim insim, IS_UCO UCO)
        {
            foreach (Connections Connection in Connections._connections.Values)
            {
                if (Connection.PLID == UCO.PLID)
                {
                    if (UCO.UCOAction == UCOAction.UCO_CIRCLE_ENTER && UCO.Info.Heading == 3)
                    {
                        if (timerSem >= 47 && timerSem <= 87)
                        {
                            if (Connection.PName.Substring(0, 5) != "[COP]")
                            {
                                insim.Send(0, Connection.UCID, "^1› ^7Você foi multado por ^1Ultrapassar o sinal vermelho!");
                                Connection.Money -= 300;
                            }
                            else
                            {
                                insim.Send(0, Connection.UCID, $"^3› ^7Você não foi ^3multado ^7por está ativo como um ^3policial!");
                            }
                        }
                    }
                    if (UCO.UCOAction == UCOAction.UCO_CP_FWD || UCO.UCOAction == UCOAction.UCO_CP_REV)
                    {
                        if (idle == 3)
                        {
                            if (Connection.PName.Substring(0, 5) != "[COP]")
                            {
                                insim.Send(0, Connection.UCID, "^1› ^7Você foi multado por ^1Ultrapassar o sinal vermelho!");
                                Connection.Money -= 300;
                            }
                            else
                            {
                                 insim.Send(0, Connection.UCID, $"^3› ^7Você não foi ^3multado ^7por está ativo como um ^3policial!");
                            }
                        }
                    }
                }
            }
        }
        private void Semaphore(object sender, ElapsedEventArgs e)
        {
            try
            {
                timerSem += 1;
                if (timerSem >= 0 && timerSem <= 40)
                {
                    insim.Send(new IS_OCO { Data = BulbInfo.Red1, Identifier = 0, Index = OCOIndex.AXO_START_LIGHTS, OCOAction = OCOAction.OCO_LIGHTS_SET });
                    idle = 3;
                }
                if (timerSem >= 41 && timerSem <= 45)
                {
                    insim.Send(new IS_OCO { Data = BulbInfo.Red2, Identifier = 0, Index = OCOIndex.AXO_START_LIGHTS, OCOAction = OCOAction.OCO_LIGHTS_SET });
                    idle = 2;
                }
                if (timerSem >= 47 && timerSem <= 87)
                {
                    insim.Send(new IS_OCO { Data = BulbInfo.Green, Identifier = 0, Index = OCOIndex.AXO_START_LIGHTS, OCOAction = OCOAction.OCO_LIGHTS_SET });
                    idle = 1;
                }
                if (timerSem >= 88 && timerSem <= 93)
                {
                    insim.Send(new IS_OCO { Data = BulbInfo.Red1, Identifier = 0, Index = OCOIndex.AXO_START_LIGHTS, OCOAction = OCOAction.OCO_LIGHTS_SET });
                    idle = 3;
                }

                if (timerSem >= 0 && timerSem <= 40)
                {
                    insim.Send(new IS_OCO { Data = BulbInfo.Green, Identifier = 1, Index = OCOIndex.AXO_START_LIGHTS, OCOAction = OCOAction.OCO_LIGHTS_SET });
                }
                if (timerSem >= 41 && timerSem <= 45)
                {
                    insim.Send(new IS_OCO { Data = BulbInfo.Red2, Identifier = 1, Index = OCOIndex.AXO_START_LIGHTS, OCOAction = OCOAction.OCO_LIGHTS_SET });
                }
                if (timerSem >= 47 && timerSem <= 87)
                {
                    insim.Send(new IS_OCO { Data = BulbInfo.Red1, Identifier = 1, Index = OCOIndex.AXO_START_LIGHTS, OCOAction = OCOAction.OCO_LIGHTS_SET });
                }
                if (timerSem >= 88 && timerSem <= 93)
                {
                    insim.Send(new IS_OCO { Data = BulbInfo.Green, Identifier = 1, Index = OCOIndex.AXO_START_LIGHTS, OCOAction = OCOAction.OCO_LIGHTS_SET });
                }

                if (timerSem >= 94)
                {
                    timerSem = 0;
                }
            }
            catch { }
        }
        private void MessageInSim(object sender, ElapsedEventArgs e)
        {
            try
            {
                DateTime date = DateTime.Now;
                var formattedDate = String.Format("{0:dd/MM/yyyy HH:mm}", date);
                insim.Send(255, 255, $"^7LFS ^1Street ^7: ^7{formattedDate}");
            }
            catch { }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void button3_Click(object sender, EventArgs e)
        {
            InitializeInSim();
        }
    }
}
