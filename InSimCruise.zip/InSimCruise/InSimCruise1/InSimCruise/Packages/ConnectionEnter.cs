﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using InSimCruise.Others;
using InSimDotNet;
using InSimDotNet.Packets;

namespace InSimCruise.Packages
{
    public class ConnectionEnter
    {
        public static void NCN(InSim insim, IS_NCN NCN)
        {
            try
            {
                Connections._connections.Add(NCN.UCID, new Connections()
                {
                    UCID = NCN.UCID,
                    UName = NCN.UName,
                    PName = NCN.PName,
                    Administrador = NCN.Admin
                });
                foreach (Connections Connection in Connections._connections.Values)
                {
                    if (Connection.UCID == NCN.UCID)
                    {
                        insim.Send(new IS_BTN { Text = "", BStyle = ButtonStyles.ISB_DARK, H = 100, W = 53, T = 36, L = 74, ClickID = 15, UCID = Connection.UCID, ReqI = 2 }); //
                        insim.Send(new IS_BTN { Text = "^6• ^7APRESENTACÃO", BStyle = ButtonStyles.ISB_LIGHT, H = 13, W = 51, T = 38, L = 75, ClickID = 16, UCID = Connection.UCID, ReqI = 2 }); //
                        insim.Send(new IS_BTN { Text = "^7Seja bem-vindo ao LFS Street, somos uma comunidade", BStyle = ButtonStyles.ISB_C2, H = 4, W = 75, T = 54, L = 64, ClickID = 17, UCID = Connection.UCID, ReqI = 2 }); //
                        insim.Send(new IS_BTN { Text = "^7de Live For Speed com o intuito de trazer diversão.", BStyle = ButtonStyles.ISB_C2, H = 4, W = 79, T = 59, L = 62, ClickID = 18, UCID = Connection.UCID, ReqI = 2 }); //
                        insim.Send(new IS_BTN { Text = "^6• ^7COMANDOS", BStyle = ButtonStyles.ISB_LIGHT, H = 10, W = 51, T = 67, L = 75, ClickID = 19, UCID = Connection.UCID, ReqI = 2 }); //
                        insim.Send(new IS_BTN { Text = "^6Fechar", BStyle = ButtonStyles.ISB_LIGHT, H = 7, W = 51, T = 127, L = 75, ClickID = 20, UCID = Connection.UCID, ReqI = 2 }); //
                        insim.Send(new IS_BTN { Text = "", BStyle = ButtonStyles.ISB_CLICK, H = 7, W = 51, T = 127, L = 75, ClickID = 21, UCID = Connection.UCID, ReqI = 2 }); //

                        insim.Send(new IS_BTN { Text = $"^7Dinheiro: ^2${Connection.Money}", BStyle = ButtonStyles.ISB_DARK, H = 4, W = 23, T = 2, L = 58, ClickID = 1, UCID = Connection.UCID, ReqI = 2 });
                        insim.Send(new IS_BTN { Text = $"^7Classe: ^2A ^7 | Carro: ^2UF1 ^7| Km's: ^2{Convert.ToDecimal(Connection.Distance/1000 * 0.10)}", BStyle = ButtonStyles.ISB_DARK, H = 4, W = 39, T = 2, L = 81, ClickID = 2, UCID = Connection.UCID, ReqI = 2 }); //
                        insim.Send(new IS_BTN { Text = "^7Bônus: ^20% 1x", BStyle = ButtonStyles.ISB_DARK, H = 4, W = 23, T = 2, L = 120, ClickID = 3, UCID = Connection.UCID, ReqI = 2 }); //
                        insim.Send(new IS_BTN { Text = "^7Vida: ^2100%", BStyle = ButtonStyles.ISB_DARK, H = 4, W = 23, T = 6, L = 58, ClickID = 4, UCID = Connection.UCID, ReqI = 2 }); //
                        insim.Send(new IS_BTN { Text = "^7Missão: ^2Nenhuma", BStyle = ButtonStyles.ISB_DARK, H = 4, W = 23, T = 6, L = 120, ClickID = 5, UCID = Connection.UCID, ReqI = 2 }); //
                        insim.Send(new IS_BTN { Text = $"^7Pit-Stop ^2(80km/h)", BStyle = ButtonStyles.ISB_DARK, H = 4, W = 39, T = 6, L = 81, ClickID = 6, UCID = Connection.UCID, ReqI = 2 }); //
                        insim.Send(new IS_BTN { Text = "^7Cinto: ^2Solto", BStyle = ButtonStyles.ISB_DARK, H = 4, W = 22, T = 184, L = 10, ClickID = 7, UCID = Connection.UCID, ReqI = 2 });

                        System.Timers.Timer TimerInterface = new System.Timers.Timer(1000);
                        TimerInterface.Elapsed += new System.Timers.ElapsedEventHandler(UpdateInterface);
                        TimerInterface.Enabled = true;

                        System.Timers.Timer TimerBonus = new System.Timers.Timer(50000);
                        TimerBonus.Elapsed += new System.Timers.ElapsedEventHandler(UpdateBonus);
                        TimerBonus.Enabled = true;

                        void UpdateInterface(object sender, ElapsedEventArgs e)
                        {
                            insim.Send(new IS_BTN { Text = $"^7Dinheiro: ^2${Connection.Money}", BStyle = ButtonStyles.ISB_DARK, H = 4, W = 23, T = 2, L = 58, ClickID = 1, UCID = Connection.UCID, ReqI = 2 });
                            insim.Send(new IS_BTN { Text = $"^7Classe: ^2B ^7| Carro: ^2FZ5 ^7| ^7Km's: ^2{Convert.ToDecimal(Connection.Distance / 1000 * 0.10)}", BStyle = ButtonStyles.ISB_DARK, H = 4, W = 39, T = 2, L = 81, ClickID = 2, UCID = Connection.UCID, ReqI = 2 }); //
                            insim.Send(new IS_BTN { Text = $"^7Bônus: ^2{Connection.BonusPorcentagem}% {Connection.BonusMultiplicador}x", BStyle = ButtonStyles.ISB_DARK, H = 4, W = 23, T = 2, L = 120, ClickID = 3, UCID = Connection.UCID, ReqI = 2 }); //
                            insim.Send(new IS_BTN { Text = "^7Vida: ^2100%", BStyle = ButtonStyles.ISB_DARK, H = 4, W = 23, T = 6, L = 58, ClickID = 4, UCID = Connection.UCID, ReqI = 2 }); //
                            insim.Send(new IS_BTN { Text = "^7Missão: ^2Nenhuma", BStyle = ButtonStyles.ISB_DARK, H = 4, W = 23, T = 6, L = 120, ClickID = 5, UCID = Connection.UCID, ReqI = 2 }); //
                        }
                        void UpdateBonus(object sender, ElapsedEventArgs e)
                        {
                            Connection.BonusPorcentagem += 1;
                            if (Connection.BonusPorcentagem > 100)
                            {
                                Random random = new Random();
                                var bonusRandom = random.Next(100, 1000);
                                Connection.Money += bonusRandom;
                                Connection.BonusMultiplicador += 1;
                                Connection.BonusPorcentagem = 0;
                                insim.Send(0, Connection.UCID, $"^2› ^7Você ganhou ^2${bonusRandom} ^7por completar o bônus!");
                            }
                        }
                    }
                }
            }
            catch { }
        }
    }
}