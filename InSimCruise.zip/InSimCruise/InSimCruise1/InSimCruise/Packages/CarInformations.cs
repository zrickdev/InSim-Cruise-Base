﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InSimDotNet;
using InSimDotNet.Packets;
using InSimCruise.Others;
using InSimDotNet.Helpers;
using System.Timers;

namespace InSimCruise.Packages
{
    public class CarInformations
    {
        public static void MCI(InSim insim, IS_MCI MCI)
        {
            try
            {
                foreach (CompCar car in MCI.Info)
                {
                    if (Players._players.TryGetValue(car.PLID, out Players NPL))
                    {
                        foreach (Connections Connection in Connections._connections.Values)
                        {
                            if (Connection.PLID == car.PLID)
                            {
                                Connection.X = (car.X / 65536);
                                Connection.Y = (car.Y / 65536);
                                Connection.Z = (car.Z / 65536);

                                Connection.Heading = ((car.Heading / 256) + 128);
                                Connection.Angle = (car.AngVel / 16384);
                                Connection.Speed = car.Speed;

                                if (Connection.KMH() > 1)
                                {
                                    if (Connection.X != 0 && Connection.Y != 0 && Connection.Z != 0)
                                    {
                                        var distance = MathHelper.Distance(
                                            Connection.X,
                                            Connection.Y,
                                            Connection.Z,
                                            car.X,
                                            car.Y,
                                            car.Z);
                                        Connection.Distance += (int)MathHelper.LengthToMeters(distance);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch { }
        }
    }
}
