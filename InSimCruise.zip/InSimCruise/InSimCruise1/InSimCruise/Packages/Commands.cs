﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InSimDotNet;
using InSimDotNet.Packets;
using InSimCruise.Others;


namespace InSimCruise.Packages
{
    public class Commands
    {
        public static void MSO(InSim insim, IS_MSO MSO)
        {
            foreach (Connections Connection in Connections._connections.Values)
            {
                if (Connection.UCID == MSO.UCID)
                {
                    if (MSO.UserType == UserType.MSO_PREFIX)
                    {
                        string Text = MSO.Msg.Substring(MSO.TextStart, (MSO.Msg.Length - MSO.TextStart));
                        string[] command = Text.Split(' ');
                        command[0] = command[0].ToLower();

                        switch (command[0])
                        {

                            case "!gps":
                                {
                                     insim.Send(new IS_BTN { Text = "", BStyle = ButtonStyles.ISB_DARK, H = 16, W = 22, T = 168, L = 10, ClickID = 8, UCID = Connection.UCID, ReqI = 2 }); //
                                     insim.Send(new IS_BTN { Text = "^7Definir Local", BStyle = ButtonStyles.ISB_LIGHT, H = 5, W = 20, T = 177, L = 11, ClickID = 9, UCID = Connection.UCID, ReqI = 2 }); //
                                     insim.Send(new IS_BTN { Text = "", BStyle = ButtonStyles.ISB_CLICK, H = 7, W = 20, T = 176, L = 11, ClickID = 10, UCID = Connection.UCID, ReqI = 2 }); //
                                     insim.Send(new IS_BTN { Text = "", BStyle = ButtonStyles.ISB_LIGHT, H = 7, W = 20, T = 170, L = 11, ClickID = 11, UCID = Connection.UCID, ReqI = 2 }); //
                                     insim.Send(new IS_BTN { Text = $"^7Gps: ^2{Connection.Location}", BStyle = ButtonStyles.ISB_C1, H = 5, W = 19, T = 171, L = 12, ClickID = 12, UCID = Connection.UCID, ReqI = 2 }); //
                                }
                                break;

                            case "!fechar":
                                {
                                    insim.Send(new IS_BFN { UCID = Connection.UCID, ClickID = 25, SubT = ButtonFunction.BFN_DEL_BTN });
                                }
                                break;

                            default:
                                {
                                    insim.Send(Connection.PLID, Connection.UCID, $"^1› ^7Comando ^7inexistente!");
                                }
                                break;
                        }
                    }
                }
            }
        }
    }
}
