﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using InSimCruise.Others;
using InSimDotNet;
using InSimDotNet.Packets;

namespace InSimCruise.Packages
{
    public class ConnectionNew
    {
        public static void NPL(InSim insim, IS_NPL NPL)
        {
            try
            {
                if (Players._players.ContainsKey(NPL.PLID))
                {
                    Players._players[NPL.PLID].UCID = NPL.UCID;
                    Players._players[NPL.PLID].PLID = NPL.PLID;
                    Players._players[NPL.PLID].PName = NPL.PName;
                    Players._players[NPL.PLID].CName = NPL.CName;
                }
                else
                {
                    Players._players.Add(NPL.PLID, new Players
                    {
                        UCID = NPL.UCID,
                        PLID = NPL.PLID,
                        PName = NPL.PName,
                        CName = NPL.CName
                    });
                }

                foreach (Connections Connection in Connections._connections.Values)
                {
                    if (Connection.UCID == NPL.UCID)
                    {
                        Connection.PLID = NPL.PLID;
                        if (Connection.PName.Substring(0, 5) == "[COP]")
                        {
                            insim.Send(255, 255, $"^4› ^4{Connection.UName} ^7está ativo como um Policial!");
                            insim.Send($"/cansiren {Connection.UName} 1");
                        }
                    }
                }
            }
            catch { }
        }
    }
}