﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InSimDotNet;
using InSimCruise.Others;
using InSimDotNet.Packets;


namespace InSimCruise.Packages
{
    public class ButtonsClick
    {
        public static void BTC(InSim insim, IS_BTC BTC)
        {
            foreach (Connections Connection in Connections._connections.Values)
            {
                if (Connection.UCID == BTC.UCID)
                {
                    if (BTC.ClickID == 21)
                    {
                        insim.Send(new IS_BFN { UCID = Connection.UCID, ClickID = 15, SubT = ButtonFunction.BFN_DEL_BTN });
                        insim.Send(new IS_BFN { UCID = Connection.UCID, ClickID = 16, SubT = ButtonFunction.BFN_DEL_BTN });
                        insim.Send(new IS_BFN { UCID = Connection.UCID, ClickID = 17, SubT = ButtonFunction.BFN_DEL_BTN });
                        insim.Send(new IS_BFN { UCID = Connection.UCID, ClickID = 18, SubT = ButtonFunction.BFN_DEL_BTN });
                        insim.Send(new IS_BFN { UCID = Connection.UCID, ClickID = 19, SubT = ButtonFunction.BFN_DEL_BTN });
                        insim.Send(new IS_BFN { UCID = Connection.UCID, ClickID = 20, SubT = ButtonFunction.BFN_DEL_BTN });
                        insim.Send(new IS_BFN { UCID = Connection.UCID, ClickID = 21, SubT = ButtonFunction.BFN_DEL_BTN });
                    }
                    if (BTC.ClickID == 10)
                    {
                        insim.Send(new IS_BTN { Text = "", BStyle = ButtonStyles.ISB_DARK, H = 80, W = 53, T = 43, L = 72, ClickID = 25, UCID = Connection.UCID, ReqI = 2 }); //
                    }
                }
            }
        }
    }
}
