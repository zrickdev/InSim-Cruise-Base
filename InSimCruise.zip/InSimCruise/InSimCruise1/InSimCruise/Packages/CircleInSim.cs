﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InSimDotNet;
using InSimDotNet.Packets;
using InSimCruise.Others;

namespace InSimCruise.Packages
{
    public class CircleInSim
    {
        public static void UCO(InSim insim, IS_UCO UCO)
        {
            try
            {
                foreach (Connections Connection in Connections._connections.Values)
                {
                    if (Connection.PLID == UCO.PLID)
                    {
                        if (UCO.UCOAction == UCOAction.UCO_CIRCLE_ENTER && UCO.Info.Heading == 0)
                        {
                            insim.Send(new IS_BTN { Text = $"^7Westhill ^2(140km/h)", BStyle = ButtonStyles.ISB_DARK, H = 4, W = 39, T = 6, L = 81, ClickID = 6, UCID = Connection.UCID, ReqI = 2 }); //
                            return;
                        }
                        if (UCO.UCOAction == UCOAction.UCO_CIRCLE_ENTER && UCO.Info.Heading == 1)
                        {
                            insim.Send(new IS_BTN { Text = $"^7Pit-Stop ^2(80km/h)", BStyle = ButtonStyles.ISB_DARK, H = 4, W = 39, T = 6, L = 81, ClickID = 6, UCID = Connection.UCID, ReqI = 2 }); //
                            return;
                        }
                        if (UCO.UCOAction == UCOAction.UCO_CIRCLE_ENTER && UCO.Info.Heading == 4)
                        {
                            if (Connection.KMH() > 145)
                            {
                                if (Connection.PName.Substring(0, 5) != "[COP]")
                                {
                                    Random random = new Random();
                                    var multaRandom = random.Next(100, 1000);
                                    Connection.Money -= multaRandom;
                                    insim.Send(0, Connection.UCID, $"^1› ^7Você foi ^1multado ^7no valor de ^1${multaRandom} ^7por ^1excesso de velocidade!");
                                }
                                else
                                {
                                    insim.Send(0, Connection.UCID, $"^3› ^7Você não foi ^3multado ^7por está ativo como um ^3policial!");
                                }
                            }
                        }
                    }
                }
            }
            catch { }
        }
    }
}
