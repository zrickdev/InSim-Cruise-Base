﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InSimDotNet;
using InSimDotNet.Packets;
using InSimCruise.Others;

namespace InSimCruise.Packages
{
    public class ConnectionLeft
    {
        public static void PLL(InSim insim, IS_PLL PLL)
        {
            try
            {
                Players._players.Remove(PLL.PLID);
            }
            catch { }
        }
        public static void PLP(InSim insim, IS_PLP PLP)
        {
            try
            {
                Players._players.Remove(PLP.PLID);
            }
            catch { }
        }
    }
}
